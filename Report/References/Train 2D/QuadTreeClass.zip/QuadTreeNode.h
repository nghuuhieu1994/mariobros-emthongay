// QuadTreeNode.h: interface for the CQuadTreeNode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined _QUADTREENODE_H_
#define _QUADTREENODE_H_

class CQuadTreeNode  
{
public:
	CQuadTreeNode(long lowerLeftX, long lowerLeftY, long width, long height, long level, long number);
	virtual ~CQuadTreeNode();

   HRESULT SubDivide();
   HRESULT AddObject(ICollidableObject* object);
   HRESULT PurgeObjects();
   HRESULT GetSize(long* llx, long* lly, long* width, long* height);
   HRESULT GetCollidableObjects(ICollidableObject* object, bool moving,
      bool excludeBalls, std::set<ICollidableObject*>& collidables);
   HRESULT RemoveObject(ICollidableObject* object, bool usePreviousPos, bool expectedToFindObj);
   HRESULT UpdateObject(ICollidableObject* object);

private:
   long m_LowerLeftX;
   long m_LowerLeftY;
   long m_Width;
   long m_Height;

   CQuadTreeNode** m_SubNodes;

   typedef std::set<ICollidableObject*> CollidablesSet;
   CollidablesSet m_Collidables;
};

#endif // _QUADTREENODE_H_
