// QuadTreeNode.cpp: implementation of the CQuadTreeNode class.
//
//////////////////////////////////////////////////////////////////////

#include "QuadTreeNode.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CQuadTreeNode::CQuadTreeNode(long lowerLeftX, long lowerLeftY, 
   long width, long height) : m_LowerLeftX(lowerLeftX), 
   m_LowerLeftY(lowerLeftY), m_Width(width), m_Height(height),
   m_SubNodes(NULL)
{
}

CQuadTreeNode::~CQuadTreeNode()
{
   if (!m_SubNodes) {
      CollidablesSet::iterator it = m_Collidables.begin();
      while (it != m_Collidables.end()) {
         (*it)->Release();      
         it++;
      }
      m_Collidables.clear();
   }
   else {
      for (int i = 0; i < 4; i++) {
         delete m_SubNodes[i];
      }
      ::CoTaskMemFree(m_SubNodes);
      assert(m_Collidables.empty());
   }
}

HRESULT CQuadTreeNode::SubDivide()
{
   HRESULT result = S_OK;
   if (!m_SubNodes) {
      // w is new width for subnodes (half of current width), h similarly
      long w = m_Width / 2;
      long h = m_Height / 2;
      // shorter variable names for current lower x,y position
      long llx = m_LowerLeftX;
      long lly = m_LowerLeftY;

      // node 0: upper left quadrant
      // node 1: upper right quadrant
      // node 2: lower right quadrant
      // node 3: lower left quaderant
      m_SubNodes = (CQuadTreeNode**)::CoTaskMemAlloc(4 * sizeof(CQuadTreeNode*));
      m_SubNodes[0] = new CQuadTreeNode(llx, lly + h, w, h, m_ID, 1);
      m_SubNodes[1] = new CQuadTreeNode(llx + w, lly + h, w, h, m_ID, 2);
      m_SubNodes[2] = new CQuadTreeNode(llx + w, lly, w, h, m_ID, 3);
      m_SubNodes[3] = new CQuadTreeNode(llx, lly, w, h, m_ID, 4);
   }
   else {
      for (int i = 0; i < 4 && SUCCEEDED(result); i++) {
         result = m_SubNodes[i]->SubDivide();
      }
   }
   return result;
}

HRESULT CQuadTreeNode::AddObject(ICollidableObject* object)
{
   HRESULT result = S_OK;
   // If this node has subnodes, figure out which subnode this object belongs
   // in and add it to him, otherwise, just add it to our list
   if (!m_SubNodes) {
      // no subnodes, this is a leaf node, so add it to the list
      std::pair<CollidablesSet::iterator, bool> newInsertion;
      newInsertion = m_Collidables.insert(object);
      if (newInsertion.second) {
         // only add ref if this is object is not already in our set,
         // otherwise we will over ref count it.
         object->AddRef();
      }
      else {
         // they should never add the same object to us twice
         assert(false);
      }
   }
   else {
      // the object may need to go in more than one sub node if it
      // spans multiple quadrants
      int collisionArray[4] = { -1, -1, -1, -1 };
      int collisionIndex = 0;
      long radius = 0;
      result = object->GetRadius(&radius);
      assert(SUCCEEDED(result));
      long lowerLeftX = 0;
      long lowerLeftY = 0;
      long width = 0;
      long height = 0;
      double cx, cy;
      result = object->GetPosition(&cx, &cy);
      long lcx, lcy;
      lcx = ::Roundoff(cx);
      lcy = ::Roundoff(cy);
      assert(SUCCEEDED(result));
      lowerLeftX = lcx - radius;
      lowerLeftY = lcy - radius;
      width = 2 * radius;
      height = width;
      long llx, lly, w, h;
      for (int i = 0; i < 4; i++) {
         result = m_SubNodes[i]->GetSize(&llx, &lly, &w, &h);
         assert(SUCCEEDED(result));
         int left1, left2;
         int right1, right2;
         int top1, top2;
         int bottom1, bottom2;

         left1 = lowerLeftX;
         left2 = llx;
         right1 = lowerLeftX + width;
         right2 = llx + w;
         bottom1 = lowerLeftY;
         bottom2 = lly;
         top1 = lowerLeftY + height;
         top2 = lly + h;
         if (bottom1 > top2 || top1 < bottom2 || right1 < left2 || left1 > right2) {
            continue;
         }
         else {
            collisionArray[collisionIndex++] = i;
         }
      }
      for (int j = 0; j < collisionIndex; j++) {
         m_SubNodes[collisionArray[j]]->AddObject(object);
      }
   }
   return result;
}

HRESULT CQuadTreeNode::PurgeObjects()
{
   HRESULT result = S_OK;
   if (!m_SubNodes) {
      CollidablesSet::iterator it = m_Collidables.begin();
      while (it != m_Collidables.end()) {
         (*it)->Release();      
         it++;
      }
      m_Collidables.clear();
   }
   else {
       for (int i = 0; i < 4; i++) {
         result = m_SubNodes[i]->PurgeObjects();
         assert(SUCCEEDED(result));
      }
      assert(m_Collidables.empty());
   }
   return result;
}

HRESULT CQuadTreeNode::GetSize(long* llx, long* lly, long* width, long* height)
{
   *llx = m_LowerLeftX;
   *lly = m_LowerLeftY;
   *width = m_Width;
   *height = m_Height;
   return S_OK;
}

// if moving is true, caller should have moved the object forward a time step before
// calling this function

HRESULT CQuadTreeNode::GetCollidableObjects(ICollidableObject* object, bool moving, bool excludeBalls,
   std::set<ICollidableObject*>& collidables)
{
   HRESULT result = S_OK;
   // If this node has subnodes, figure out which subnode this object belongs
   // in and add it to him, otherwise, just add it to our list
   if (!m_SubNodes) {
      // no subnodes, this is a leaf node, so return entire list
      CollidablesSet::iterator it = m_Collidables.begin();
      while (it != m_Collidables.end()) {
         // exclude the actual object they are passing in, since they want objects
         // other than this object in the area.
         if (*it != object) {
            // also if they want to exclude other active balls (type == Ball), then
            // exclude those
            CollidableObjectTypes objType;
            result = (*it)->GetCollidableObjectType(&objType);
            assert(SUCCEEDED(result));
            if (!(excludeBalls && objType == Ball)) {
               collidables.insert(*it);
            }
         }
         it++;
      }
   }
   else {
      // the object may need to go in more than one sub node if it
      // spans multiple quadrants
      long radius = 0;
      result = object->GetRadius(&radius);
      assert(SUCCEEDED(result));
      // create bounding box around circular object
      std::set<int> collisionSave;
      double cx, cy;
      // if the ball is moving, then look at both the ball's previous position
      // and the ball's current position, otherwise just look at the current
      // position
      int times2loop = moving ? 2 : 1;
      for (int k = 0; k < times2loop; k++) {
         if (k == 0) {
            result = object->GetPosition(&cx, &cy);
         }
         else if (k == 1) {
            result = object->GetPrevPosition(&cx, &cy);
         }
         else {
            assert(false);
         }
         assert(SUCCEEDED(result));

         long lcx, lcy;
         lcx = ::Roundoff(cx);
         lcy = ::Roundoff(cy);
         long lowerLeftX = lcx - radius;
         long lowerLeftY = lcy - radius;
         long width = 2 * radius;
         long height = width;

         long llx, lly, w, h;
         int collisionArray[4] = { -1, -1, -1, -1 };
         int collisionIndex = 0;

         for (int i = 0; i < 4; i++) {
            result = m_SubNodes[i]->GetSize(&llx, &lly, &w, &h);
            assert(SUCCEEDED(result));
            int left1, left2;
            int right1, right2;
            int top1, top2;
            int bottom1, bottom2;

            left1 = lowerLeftX;
            left2 = llx;
            right1 = lowerLeftX + width;
            right2 = llx + w;
            bottom1 = lowerLeftY;
            bottom2 = lly;
            top1 = lowerLeftY + height;
            top2 = lly + h;
            if (bottom1 > top2 || top1 < bottom2 || right1 < left2 || left1 > right2) {
               continue;
            }
            else {
               collisionArray[collisionIndex++] = i;
            }
         }
         if (k == 0) {
            for (int j = 0; j < collisionIndex; j++) {
               collisionSave.insert(collisionArray[j]);
            }
         }            
         for (int j = 0; j < collisionIndex; j++) {
            if (k == 1) {
               if (collisionSave.find(collisionArray[j]) != collisionSave.end()) {
                  continue;
               }
            }
            CollidablesSet subNodeCollidables;
            m_SubNodes[collisionArray[j]]->GetCollidableObjects(object, moving, excludeBalls, subNodeCollidables);
            CollidablesSet::iterator it = subNodeCollidables.begin();
            while (it != subNodeCollidables.end()) {
               collidables.insert(*it);
               it++;
            }
         }
      }
      cobj1->Release();
   }
   return result;
}


HRESULT CQuadTreeNode::RemoveObject(ICollidableObject* object, bool usePreviousPos, bool expectedToFindObj)
{
   HRESULT result = S_OK;
   // If this node has subnodes, figure out which subnode this object belongs
   // in and remove it from him, otherwise, just remove it to our list
   if (!m_SubNodes) {
      // no subnodes, this is a leaf node, so remove it
      CollidablesSet::iterator it = m_Collidables.find(object);
      if (it != m_Collidables.end()) {
         (*it)->Release();
         m_Collidables.erase(it);
         if (!expectedToFindObj) {
            assert(false);
         }
      }
      else {
         if (expectedToFindObj) {
            // why were we told to remove an object not in our set?
            assert(false);
         }
      }
   }
   else {
      // the object may need to be removed from more than one sub node if it
      // spans multiple quadrants
      int collisionArray[4] = { -1, -1, -1, -1 };
      int collisionIndex = 0;
#ifdef _DEBUG
      int noncollisionArray[4] = { -1, -1, -1, -1 };
      int noncollisionIndex = 0;
#endif
      long radius = 0;
      result = object->GetRadius(&radius);
      assert(SUCCEEDED(result));
      long lowerLeftX = 0;
      long lowerLeftY = 0;
      long width = 0;
      long height = 0;
      double cx, cy;
      if (usePreviousPos) {
         result = object->GetPrevPosition(&cx, &cy);
      }
      else {
         result = object->GetPosition(&cx, &cy);
      }
      long lcx, lcy;
      lcx = ::Roundoff(cx);
      lcy = ::Roundoff(cy);
      assert(SUCCEEDED(result));
      lowerLeftX = lcx - radius;
      lowerLeftY = lcy - radius;
      width = 2 * radius;
      height = width;
      long llx, lly, w, h;
      for (int i = 0; i < 4; i++) {
         result = m_SubNodes[i]->GetSize(&llx, &lly, &w, &h);
         assert(SUCCEEDED(result));
         int left1, left2;
         int right1, right2;
         int top1, top2;
         int bottom1, bottom2;

         left1 = lowerLeftX;
         left2 = llx;
         right1 = lowerLeftX + width;
         right2 = llx + w;
         bottom1 = lowerLeftY;
         bottom2 = lly;
         top1 = lowerLeftY + height;
         top2 = lly + h;
         if (bottom1 > top2 || top1 < bottom2 || right1 < left2 || left1 > right2) {
#ifdef _DEBUG
            noncollisionArray[noncollisionIndex++] = i;
#endif
            continue;
         }
         else {
            collisionArray[collisionIndex++] = i;
         }
      }
      for (int j = 0; j < collisionIndex; j++) {
         result = m_SubNodes[collisionArray[j]]->RemoveObject(object, usePreviousPos, true);
         assert(SUCCEEDED(result));
      }
#ifdef _DEBUG
      // validate that we do NOT find this object in subnodes where it should not be, since
      // it is outside of us (the parents) bounds, it should not be in our subnodes.
      for (j = 0; j < noncollisionIndex; j++) {
         result = m_SubNodes[noncollisionArray[j]]->RemoveObject(object, usePreviousPos, false);
         assert(SUCCEEDED(result));
      }
#endif
   }
   return result;
}

// Call if an object has moved and needs to be updated in the quad tree
HRESULT CQuadTreeNode::UpdateObject(ICollidableObject* obj)
{
   HRESULT result = S_OK;
   if (!m_SubNodes) {
      // this function should only be called on a quad tree node with sub nodes
      assert(false);
      result = E_FAIL;
   }
   else {
      // first remove the object from subnodes based on its previous position, then add it
      // back with current position.
      for (int i = 0; i < 4; i++) {
         result = m_SubNodes[i]->RemoveObject(obj, true, true);
         assert(SUCCEEDED(result));
      }
      for (i = 0; i < 4; i++) {
         result = m_SubNodes[i]->AddObject(obj);
         assert(SUCCEEDED(result));
      }
   }
   return result;
}